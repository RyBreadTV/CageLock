Chat plugin config files are stored in this directory.
