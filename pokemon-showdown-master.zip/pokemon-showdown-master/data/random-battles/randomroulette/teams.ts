import RandomTeams from '../gen9/teams';

export class RandomRandomRouletteTeams extends RandomTeams {}

export default RandomRandomRouletteTeams;
