import RandomGen5Teams from '../gen5/teams';

export class RandomGen5PokebilitiesTeams extends RandomGen5Teams {}

export default RandomGen5PokebilitiesTeams;
