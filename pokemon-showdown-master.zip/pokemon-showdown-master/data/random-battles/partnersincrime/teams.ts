import RandomTeams from '../gen9/teams';

export class RandomPartnersInCrimeTeams extends RandomTeams {}

export default RandomPartnersInCrimeTeams;
