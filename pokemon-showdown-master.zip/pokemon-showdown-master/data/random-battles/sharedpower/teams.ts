import RandomTeams from '../gen9/teams';

export class RandomSharedPowerTeams extends RandomTeams {}

export default RandomSharedPowerTeams;
