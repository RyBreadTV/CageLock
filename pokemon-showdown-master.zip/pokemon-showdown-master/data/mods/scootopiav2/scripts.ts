export const Scripts: ModdedBattleScriptsData = {
	gen: 9,
};
