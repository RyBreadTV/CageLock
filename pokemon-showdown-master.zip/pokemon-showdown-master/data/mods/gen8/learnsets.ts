export const Learnsets: import('../../../sim/dex-species').ModdedLearnsetDataTable = {
	vivillonfancy: {
		inherit: true,
		eventOnly: true,
	},
};
