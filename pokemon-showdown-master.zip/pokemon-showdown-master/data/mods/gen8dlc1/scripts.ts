export const Scripts: ModdedBattleScriptsData = {
	gen: 8,
	inherit: 'gen8',
};
