export const FormatsData: import('../../../sim/dex-species').ModdedSpeciesFormatsDataTable = {
	bulbasaur: {
		tier: "LC",
	},
	ivysaur: {
		tier: "ZU",
	},
	venusaur: {
		tier: "UUBL",
	},
	charmander: {
		tier: "LC",
	},
	charmeleon: {
		tier: "PU",
	},
	charizard: {
		tier: "OU",
	},
	squirtle: {
		tier: "LC",
	},
	wartortle: {
		tier: "PU",
	},
	blastoise: {
		tier: "UU",
	},
	caterpie: {
		tier: "LC",
	},
	metapod: {
		tier: "NFE",
	},
	butterfree: {
		tier: "ZU",
	},
	weedle: {
		tier: "LC",
	},
	kakuna: {
		tier: "NFE",
	},
	beedrill: {
		tier: "ZU",
	},
	pidgey: {
		tier: "LC",
	},
	pidgeotto: {
		tier: "NFE",
	},
	pidgeot: {
		tier: "NU",
	},
	rattata: {
		tier: "LC",
	},
	raticate: {
		tier: "NU",
	},
	spearow: {
		tier: "LC",
	},
	fearow: {
		tier: "UU",
	},
	ekans: {
		tier: "LC",
	},
	arbok: {
		tier: "PU",
	},
	pichu: {
		tier: "LC",
	},
	pikachu: {
		tier: "NU",
	},
	raichu: {
		tier: "RU",
	},
	sandshrew: {
		tier: "LC",
	},
	sandslash: {
		tier: "UU",
	},
	nidoranf: {
		tier: "LC",
	},
	nidorina: {
		tier: "NFE",
	},
	nidoqueen: {
		tier: "UU",
	},
	nidoranm: {
		tier: "LC",
	},
	nidorino: {
		tier: "NFE",
	},
	nidoking: {
		tier: "UU",
	},
	cleffa: {
		tier: "LC",
	},
	clefairy: {
		tier: "NFE",
	},
	clefable: {
		tier: "RU",
	},
	vulpix: {
		tier: "LC",
	},
	ninetales: {
		tier: "RU",
	},
	igglybuff: {
		tier: "LC",
	},
	jigglypuff: {
		tier: "NFE",
	},
	wigglytuff: {
		tier: "PU",
	},
	zubat: {
		tier: "LC",
	},
	golbat: {
		tier: "NU",
	},
	crobat: {
		tier: "UUBL",
	},
	oddish: {
		tier: "LC",
	},
	gloom: {
		tier: "ZU",
	},
	vileplume: {
		tier: "UU",
	},
	bellossom: {
		tier: "NU",
	},
	paras: {
		tier: "LC",
	},
	parasect: {
		tier: "ZU",
	},
	venonat: {
		tier: "LC",
	},
	venomoth: {
		tier: "NU",
	},
	diglett: {
		tier: "NU",
	},
	dugtrio: {
		tier: "OU",
	},
	meowth: {
		tier: "LC",
	},
	persian: {
		tier: "RU",
	},
	psyduck: {
		tier: "LC",
	},
	golduck: {
		tier: "UU",
	},
	mankey: {
		tier: "LC",
	},
	primeape: {
		tier: "RU",
	},
	growlithe: {
		tier: "LC",
	},
	arcanine: {
		tier: "UU",
	},
	poliwag: {
		tier: "LC",
	},
	poliwhirl: {
		tier: "ZUBL",
	},
	poliwrath: {
		tier: "RU",
	},
	politoed: {
		tier: "RU",
	},
	abra: {
		tier: "ZU",
	},
	kadabra: {
		tier: "UUBL",
	},
	alakazam: {
		tier: "UUBL",
	},
	machop: {
		tier: "LC",
	},
	machoke: {
		tier: "PUBL",
	},
	machamp: {
		tier: "UUBL",
	},
	bellsprout: {
		tier: "LC",
	},
	weepinbell: {
		tier: "NFE",
	},
	victreebel: {
		tier: "RU",
	},
	tentacool: {
		tier: "ZU",
	},
	tentacruel: {
		tier: "UU",
	},
	geodude: {
		tier: "LC",
	},
	graveler: {
		tier: "PU",
	},
	golem: {
		tier: "UU",
	},
	ponyta: {
		tier: "ZU",
	},
	rapidash: {
		tier: "RU",
	},
	slowpoke: {
		tier: "LC",
	},
	slowbro: {
		tier: "UUBL",
	},
	slowking: {
		tier: "UU",
	},
	magnemite: {
		tier: "ZU",
	},
	magneton: {
		tier: "OU",
	},
	farfetchd: {
		tier: "ZU",
	},
	doduo: {
		tier: "ZU",
	},
	dodrio: {
		tier: "UUBL",
	},
	seel: {
		tier: "LC",
	},
	dewgong: {
		tier: "NU",
	},
	grimer: {
		tier: "LC",
	},
	muk: {
		tier: "UU",
	},
	shellder: {
		tier: "LC",
	},
	cloyster: {
		tier: "OU",
	},
	gastly: {
		tier: "PU",
	},
	haunter: {
		tier: "NU",
	},
	gengar: {
		tier: "OU",
	},
	onix: {
		tier: "LC",
	},
	steelix: {
		tier: "UUBL",
	},
	drowzee: {
		tier: "ZU",
	},
	hypno: {
		tier: "UU",
	},
	krabby: {
		tier: "LC",
	},
	kingler: {
		tier: "PU",
	},
	voltorb: {
		tier: "ZU",
	},
	electrode: {
		tier: "UU",
	},
	exeggcute: {
		tier: "LC",
	},
	exeggutor: {
		tier: "UUBL",
	},
	cubone: {
		tier: "ZU",
	},
	marowak: {
		tier: "UUBL",
	},
	tyrogue: {
		tier: "LC",
	},
	hitmonlee: {
		tier: "UU",
	},
	hitmonchan: {
		tier: "NU",
	},
	hitmontop: {
		tier: "UU",
	},
	lickitung: {
		tier: "PU",
	},
	koffing: {
		tier: "ZU",
	},
	weezing: {
		tier: "UUBL",
	},
	rhyhorn: {
		tier: "ZU",
	},
	rhydon: {
		tier: "UUBL",
	},
	chansey: {
		tier: "UUBL",
	},
	blissey: {
		tier: "OU",
	},
	tangela: {
		tier: "PU",
	},
	kangaskhan: {
		tier: "UU",
	},
	horsea: {
		tier: "LC",
	},
	seadra: {
		tier: "PU",
	},
	kingdra: {
		tier: "UUBL",
	},
	goldeen: {
		tier: "LC",
	},
	seaking: {
		tier: "ZU",
	},
	staryu: {
		tier: "LC",
	},
	starmie: {
		tier: "OU",
	},
	mrmime: {
		tier: "RU",
	},
	scyther: {
		tier: "UU",
	},
	scizor: {
		tier: "UUBL",
	},
	smoochum: {
		tier: "LC",
	},
	jynx: {
		tier: "UUBL",
	},
	elekid: {
		tier: "ZU",
	},
	electabuzz: {
		tier: "UU",
	},
	magby: {
		tier: "LC",
	},
	magmar: {
		tier: "RU",
	},
	pinsir: {
		tier: "UU",
	},
	tauros: {
		tier: "UUBL",
	},
	magikarp: {
		tier: "LC",
	},
	gyarados: {
		tier: "OU",
	},
	lapras: {
		tier: "UU",
	},
	ditto: {
		tier: "ZU",
	},
	eevee: {
		tier: "LC",
	},
	vaporeon: {
		tier: "UUBL",
	},
	jolteon: {
		tier: "OU",
	},
	flareon: {
		tier: "NU",
	},
	espeon: {
		tier: "UUBL",
	},
	umbreon: {
		tier: "UUBL",
	},
	porygon: {
		tier: "ZU",
	},
	porygon2: {
		tier: "UUBL",
	},
	omanyte: {
		tier: "PU",
	},
	omastar: {
		tier: "UU",
	},
	kabuto: {
		tier: "LC",
	},
	kabutops: {
		tier: "RU",
	},
	aerodactyl: {
		tier: "OU",
	},
	snorlax: {
		tier: "OU",
	},
	articuno: {
		tier: "UUBL",
	},
	zapdos: {
		tier: "OU",
	},
	moltres: {
		tier: "OU",
	},
	dratini: {
		tier: "LC",
	},
	dragonair: {
		tier: "PU",
	},
	dragonite: {
		tier: "UUBL",
	},
	mewtwo: {
		tier: "Uber",
	},
	mew: {
		tier: "Uber",
	},
	chikorita: {
		tier: "LC",
	},
	bayleef: {
		tier: "NFE",
	},
	meganium: {
		tier: "RU",
	},
	cyndaquil: {
		tier: "LC",
	},
	quilava: {
		tier: "ZU",
	},
	typhlosion: {
		tier: "UUBL",
	},
	totodile: {
		tier: "LC",
	},
	croconaw: {
		tier: "NFE",
	},
	feraligatr: {
		tier: "UU",
	},
	sentret: {
		tier: "LC",
	},
	furret: {
		tier: "PU",
	},
	hoothoot: {
		tier: "LC",
	},
	noctowl: {
		tier: "ZU",
	},
	ledyba: {
		tier: "LC",
	},
	ledian: {
		tier: "ZU",
	},
	spinarak: {
		tier: "LC",
	},
	ariados: {
		tier: "ZU",
	},
	chinchou: {
		tier: "ZU",
	},
	lanturn: {
		tier: "UU",
	},
	togepi: {
		tier: "LC",
	},
	togetic: {
		tier: "PU",
	},
	natu: {
		tier: "LC",
	},
	xatu: {
		tier: "RU",
	},
	mareep: {
		tier: "LC",
	},
	flaaffy: {
		tier: "ZU",
	},
	ampharos: {
		tier: "UU",
	},
	azurill: {
		tier: "LC",
	},
	marill: {
		tier: "NFE",
	},
	azumarill: {
		tier: "RU",
	},
	sudowoodo: {
		tier: "NU",
	},
	hoppip: {
		tier: "LC",
	},
	skiploom: {
		tier: "NFE",
	},
	jumpluff: {
		tier: "RUBL",
	},
	aipom: {
		tier: "ZU",
	},
	sunkern: {
		tier: "LC",
	},
	sunflora: {
		tier: "ZU",
	},
	yanma: {
		tier: "ZUBL",
	},
	wooper: {
		tier: "LC",
	},
	quagsire: {
		tier: "UU",
	},
	murkrow: {
		tier: "NU",
	},
	misdreavus: {
		tier: "UU",
	},
	unown: {
		tier: "ZU",
	},
	wynaut: {
		tier: "Uber",
	},
	wobbuffet: {
		tier: "Uber",
	},
	girafarig: {
		tier: "UU",
	},
	pineco: {
		tier: "PU",
	},
	forretress: {
		tier: "OU",
	},
	dunsparce: {
		tier: "PUBL",
	},
	gligar: {
		tier: "UU",
	},
	snubbull: {
		tier: "LC",
	},
	granbull: {
		tier: "UU",
	},
	qwilfish: {
		tier: "UU",
	},
	shuckle: {
		tier: "PU",
	},
	heracross: {
		tier: "OU",
	},
	sneasel: {
		tier: "RU",
	},
	teddiursa: {
		tier: "LC",
	},
	ursaring: {
		tier: "UUBL",
	},
	slugma: {
		tier: "LC",
	},
	magcargo: {
		tier: "PU",
	},
	swinub: {
		tier: "LC",
	},
	piloswine: {
		tier: "PUBL",
	},
	corsola: {
		tier: "ZU",
	},
	remoraid: {
		tier: "LC",
	},
	octillery: {
		tier: "NU",
	},
	delibird: {
		tier: "ZU",
	},
	mantine: {
		tier: "RU",
	},
	skarmory: {
		tier: "OU",
	},
	houndour: {
		tier: "PU",
	},
	houndoom: {
		tier: "UUBL",
	},
	phanpy: {
		tier: "LC",
	},
	donphan: {
		tier: "UUBL",
	},
	stantler: {
		tier: "RU",
	},
	smeargle: {
		tier: "UUBL",
	},
	miltank: {
		tier: "UUBL",
	},
	raikou: {
		tier: "UUBL",
	},
	entei: {
		tier: "UUBL",
	},
	suicune: {
		tier: "OU",
	},
	larvitar: {
		tier: "LC",
	},
	pupitar: {
		tier: "NU",
	},
	tyranitar: {
		tier: "OU",
	},
	lugia: {
		tier: "Uber",
	},
	hooh: {
		tier: "Uber",
	},
	celebi: {
		tier: "OU",
	},
	treecko: {
		tier: "LC",
	},
	grovyle: {
		tier: "ZU",
	},
	sceptile: {
		tier: "UUBL",
	},
	torchic: {
		tier: "LC",
	},
	combusken: {
		tier: "PU",
	},
	blaziken: {
		tier: "UUBL",
	},
	mudkip: {
		tier: "LC",
	},
	marshtomp: {
		tier: "PU",
	},
	swampert: {
		tier: "OU",
	},
	poochyena: {
		tier: "LC",
	},
	mightyena: {
		tier: "ZU",
	},
	zigzagoon: {
		tier: "NFE",
	},
	linoone: {
		tier: "UUBL",
	},
	wurmple: {
		tier: "LC",
	},
	silcoon: {
		tier: "NFE",
	},
	beautifly: {
		tier: "ZU",
	},
	cascoon: {
		tier: "NFE",
	},
	dustox: {
		tier: "ZU",
	},
	lotad: {
		tier: "LC",
	},
	lombre: {
		tier: "NFE",
	},
	ludicolo: {
		tier: "UUBL",
	},
	seedot: {
		tier: "LC",
	},
	nuzleaf: {
		tier: "NFE",
	},
	shiftry: {
		tier: "RU",
	},
	taillow: {
		tier: "LC",
	},
	swellow: {
		tier: "UUBL",
	},
	wingull: {
		tier: "LC",
	},
	pelipper: {
		tier: "NU",
	},
	ralts: {
		tier: "LC",
	},
	kirlia: {
		tier: "NFE",
	},
	gardevoir: {
		tier: "UUBL",
	},
	surskit: {
		tier: "LC",
	},
	masquerain: {
		tier: "ZU",
	},
	shroomish: {
		tier: "LC",
	},
	breloom: {
		tier: "OU",
	},
	slakoth: {
		tier: "LC",
	},
	vigoroth: {
		tier: "NU",
	},
	slaking: {
		tier: "UUBL",
	},
	nincada: {
		tier: "LC",
	},
	ninjask: {
		tier: "RUBL",
	},
	shedinja: {
		tier: "PU",
	},
	whismur: {
		tier: "LC",
	},
	loudred: {
		tier: "NFE",
	},
	exploud: {
		tier: "RU",
	},
	makuhita: {
		tier: "LC",
	},
	hariyama: {
		tier: "UUBL",
	},
	nosepass: {
		tier: "ZU",
	},
	skitty: {
		tier: "LC",
	},
	delcatty: {
		tier: "ZU",
	},
	sableye: {
		tier: "NU",
	},
	mawile: {
		tier: "PU",
	},
	aron: {
		tier: "LC",
	},
	lairon: {
		tier: "ZUBL",
	},
	aggron: {
		tier: "RU",
	},
	meditite: {
		tier: "ZU",
	},
	medicham: {
		tier: "OU",
	},
	electrike: {
		tier: "LC",
	},
	manectric: {
		tier: "UU",
	},
	plusle: {
		tier: "NU",
	},
	minun: {
		tier: "PU",
	},
	volbeat: {
		tier: "ZU",
	},
	illumise: {
		tier: "ZU",
	},
	roselia: {
		tier: "NU",
	},
	gulpin: {
		tier: "LC",
	},
	swalot: {
		tier: "PU",
	},
	carvanha: {
		tier: "LC",
	},
	sharpedo: {
		tier: "RU",
	},
	wailmer: {
		tier: "LC",
	},
	wailord: {
		tier: "NU",
	},
	numel: {
		tier: "LC",
	},
	camerupt: {
		tier: "RU",
	},
	torkoal: {
		tier: "NU",
	},
	spoink: {
		tier: "LC",
	},
	grumpig: {
		tier: "UU",
	},
	spinda: {
		tier: "ZU",
	},
	trapinch: {
		tier: "PU",
	},
	vibrava: {
		tier: "PU",
	},
	flygon: {
		tier: "OU",
	},
	cacnea: {
		tier: "LC",
	},
	cacturne: {
		tier: "NU",
	},
	swablu: {
		tier: "LC",
	},
	altaria: {
		tier: "UU",
	},
	zangoose: {
		tier: "UUBL",
	},
	seviper: {
		tier: "PU",
	},
	lunatone: {
		tier: "UU",
	},
	solrock: {
		tier: "UU",
	},
	barboach: {
		tier: "LC",
	},
	whiscash: {
		tier: "NU",
	},
	corphish: {
		tier: "LC",
	},
	crawdaunt: {
		tier: "NU",
	},
	baltoy: {
		tier: "LC",
	},
	claydol: {
		tier: "OU",
	},
	lileep: {
		tier: "ZU",
	},
	cradily: {
		tier: "UU",
	},
	anorith: {
		tier: "ZU",
	},
	armaldo: {
		tier: "UUBL",
	},
	feebas: {
		tier: "LC",
	},
	milotic: {
		tier: "OU",
	},
	castform: {
		tier: "ZU",
	},
	castformsunny: {
	},
	castformrainy: {
	},
	castformsnowy: {
	},
	kecleon: {
		tier: "NU",
	},
	shuppet: {
		tier: "LC",
	},
	banette: {
		tier: "RU",
	},
	duskull: {
		tier: "PU",
	},
	dusclops: {
		tier: "UUBL",
	},
	tropius: {
		tier: "ZU",
	},
	chimecho: {
		tier: "NU",
	},
	absol: {
		tier: "RU",
	},
	snorunt: {
		tier: "LC",
	},
	glalie: {
		tier: "NUBL",
	},
	spheal: {
		tier: "LC",
	},
	sealeo: {
		tier: "PU",
	},
	walrein: {
		tier: "UU",
	},
	clamperl: {
		tier: "PU",
	},
	huntail: {
		tier: "NU",
	},
	gorebyss: {
		tier: "UU",
	},
	relicanth: {
		tier: "NU",
	},
	luvdisc: {
		tier: "ZU",
	},
	bagon: {
		tier: "LC",
	},
	shelgon: {
		tier: "ZUBL",
	},
	salamence: {
		tier: "OU",
	},
	beldum: {
		tier: "LC",
	},
	metang: {
		tier: "NU",
	},
	metagross: {
		tier: "OU",
	},
	regirock: {
		tier: "UUBL",
	},
	regice: {
		tier: "UUBL",
	},
	registeel: {
		tier: "UUBL",
	},
	latias: {
		tier: "Uber",
	},
	latios: {
		tier: "Uber",
	},
	kyogre: {
		tier: "Uber",
	},
	groudon: {
		tier: "Uber",
	},
	rayquaza: {
		tier: "Uber",
	},
	jirachi: {
		tier: "OU",
	},
	deoxys: {
		tier: "Uber",
	},
	deoxysattack: {
		tier: "Uber",
	},
	deoxysdefense: {
		tier: "Uber",
	},
	deoxysspeed: {
		tier: "Uber",
	},
};
