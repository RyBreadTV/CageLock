export const Items: import('../../../sim/dex-items').ModdedItemDataTable = {
	apicotberry: {
		inherit: true,
		isNonstandard: "Unobtainable",
	},
	berryjuice: {
		inherit: true,
		isNonstandard: "Unobtainable",
	},
	enigmaberry: {
		inherit: true,
		isNonstandard: "Unobtainable",
	},
	fastball: {
		inherit: true,
		isNonstandard: "Unobtainable",
	},
	ganlonberry: {
		inherit: true,
		isNonstandard: "Unobtainable",
	},
	heavyball: {
		inherit: true,
		isNonstandard: "Unobtainable",
	},
	lansatberry: {
		inherit: true,
		isNonstandard: "Unobtainable",
	},
	levelball: {
		inherit: true,
		isNonstandard: "Unobtainable",
	},
	loveball: {
		inherit: true,
		isNonstandard: "Unobtainable",
	},
	lureball: {
		inherit: true,
		isNonstandard: "Unobtainable",
	},
	moonball: {
		inherit: true,
		isNonstandard: "Unobtainable",
	},
	petayaberry: {
		inherit: true,
		isNonstandard: "Unobtainable",
	},
	salacberry: {
		inherit: true,
		isNonstandard: "Unobtainable",
	},
	sportball: {
		inherit: true,
		isNonstandard: "Unobtainable",
	},
	starfberry: {
		inherit: true,
		isNonstandard: "Unobtainable",
	},
};
