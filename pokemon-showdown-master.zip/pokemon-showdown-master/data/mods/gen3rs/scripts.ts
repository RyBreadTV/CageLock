export const Scripts: ModdedBattleScriptsData = {
	inherit: 'gen3',
};
