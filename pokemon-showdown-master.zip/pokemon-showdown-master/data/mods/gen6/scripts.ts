export const Scripts: ModdedBattleScriptsData = {
	inherit: 'gen7',
	gen: 6,
};
