export const FormatsData: import('../../../sim/dex-species').ModdedSpeciesFormatsDataTable = {
	pichuspikyeared: {
		isNonstandard: "Future",
		tier: "Illegal",
	},
};
