Logs of chat rooms are stored in this directory if `logchat` is enabled.
